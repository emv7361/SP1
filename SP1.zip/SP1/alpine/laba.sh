#!/bin/bash
echo "Elenetz Maria"
echo "Repositories"
echo "displaying repository information, add repository"
answer=y
while [[ $answer == "y" ]]
do
	echo "repository list"
	cat /etc/apk/repositories
	echo "Enter repository name"
	read repname
	if grep $repname etc/apk/repositories
	then
		echo "that's all for $repname"		
	else
		echo "No repository found. Enter new data"
		echo "Enter Version: 
version							date

edge                                              30-Sep-2015 07:58                   
latest-stable                                     06-Dec-2019 18:36                  
v2.4                                              19-Dec-2012 15:22                   v2.5                                              31-Oct-2012 12:46                   
v2.6                                              09-Oct-2013 13:50                   
v2.7                                              12-Mar-2014 12:55                   
v3.0                                              07-May-2014 22:52                   
v3.1                                              01-Jan-2015 07:25                  
v3.10                                             31-May-2019 18:14                   v3.11                                             06-Dec-2019 18:36                   
v3.2                                              24-Apr-2015 09:24                   
v3.3                                              21-Dec-2015 14:43                   
v3.4                                              21-Apr-2016 12:39                   
v3.5                                              16-Nov-2016 16:01                   
v3.6                                              20-Apr-2017 10:47                   
v3.7                                              23-Nov-2017 21:25                   
v3.8                                              27-Apr-2018 06:06                   
v3.9                                              15-Nov-2018 16:03                   "
		read rvers
		echo "enter repository (main or community)"
		read rep
		echo "http://dl-cdn.alpinelinux.org/alpine/$rvers/$rep" >> etc/apk/repositories
		apk update
		fi
		echo "Do you want to restart program? (y-yes, other key - no)"
		read answer
done
