#!/bin/bash
echo "Elenetz Maria"
echo "Repositories"
echo "displaying repository information, creating a new repository file"
answer=y
while [[ $answer == "y" ]]
do
	echo "repository list"
	yum repolist all
	echo "Enter repository name"
	read repname
	if grep $repname -r /etc/yum.repos.d/
	then
		yum repoinfo $repname		
	else
		echo "No repository found.Еnter repository configuration data"
		echo "Еnter Repository ID "
		read repoID
		echo "Еnter Repository name "
		read rname
		echo "Еnter Repository Baseurl. It must be http, ftp, file or https "
		read rBaseurl
		echo "Еnter Repository Enabled. 1-Enable,0-Disable "
		read rEnabled
		case "$rEnabled" in
			"1" ) echo "ok";;
			"0" ) echo "ok";;
			* ) echo "Error input,try again!";;
		esac		 
		echo "[$repoID]" > /etc/yum.repos.d/$rname.repo
		echo "name=$rname" >> /etc/yum.repos.d/$rname.repo
		echo "baseurl=$rBaseurl" >> /etc/yum.repos.d/$rname.repo
		echo "enabled=$rEnabled" >> /etc/yum.repos.d/$rname.repo		
	fi
	echo "Do you want to restart program? (y-yes, other key - no)"
	read answer
done
